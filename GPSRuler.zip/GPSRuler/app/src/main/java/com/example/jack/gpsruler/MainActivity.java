package com.example.jack.gpsruler;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import androidx.annotation.NonNull;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jack.gpsruler.toolsclass.GpsTools;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public int REQUEST_FINE_LOCATION = 1;


    private Button startAbutton;
    private Button startBbutton;
    private Button stopButton;
    private Button mapButton;
    private TextView statusTextView;
    private TextView aposTextView;
    private TextView bposTextView;
    private TextView distanceTextView;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private ArrayList<Location> pointAPoints = new ArrayList<Location>();
    private ArrayList<Location> pointBPoints = new ArrayList<Location>();
    private boolean aActive = false;
    private boolean bActive = false;

    final double METERS_TO_FEET = 3.28084;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startAbutton = (Button) findViewById(R.id.startAbutton);
        startBbutton = (Button) findViewById(R.id.startBbutton);
        stopButton = (Button) findViewById(R.id.stopButton);
        mapButton = (Button) findViewById(R.id.mapbutton);

        statusTextView = (TextView) findViewById(R.id.statustextview);
        aposTextView = (TextView) findViewById(R.id.aposition);
        bposTextView = (TextView) findViewById(R.id.bposition);
        distanceTextView = (TextView) findViewById(R.id.averagepos);

        setupButtons();

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (aActive) {
                    pointAPoints.add(location);
                    Location locA = GpsTools.average(pointAPoints);
                    System.out.println(locA.getLatitude());
                    aposTextView.setText(locA.getLatitude() + "\n" + locA.getLongitude() + "\n"
                            + locA.getAltitude());
                }

                if (bActive){
                    pointBPoints.add(location);
                    Location locB = GpsTools.average(pointBPoints);
                    bposTextView.setText(locB.getLatitude() + "\n" + locB.getLongitude() + "\n" +
                            locB.getAltitude());
                }

                if (pointAPoints.size() > 0 && pointBPoints.size() > 0) {
                    Location locA = GpsTools.average(pointAPoints);
                    Location locB = GpsTools.average(pointBPoints);
                    double distance = locA.distanceTo(locB);
                    distanceTextView.setText((distance * METERS_TO_FEET) +
                            "\n" + (GpsTools.standardPropagated(pointAPoints, pointBPoints) *
                            METERS_TO_FEET));
                }


            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };

        checkPermissions();

    }

    @TargetApi(Build.VERSION_CODES.M)
    private void checkPermissions(){
        //Toast.makeText(this, "Checking Permissions", Toast.LENGTH_SHORT).show();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            //Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            locationManager.requestLocationUpdates("gps", 3000, 0, locationListener);
        }else{
            if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(this, "GPS permission is required to measure distances",
            Toast.LENGTH_LONG).show();
            }
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_FINE_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                checkPermissions();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupButtons() {
        startAbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bActive){
                    Toast.makeText(MainActivity.this, "Please stop recording B first",
                            Toast.LENGTH_SHORT).show();
                }else{
                    aActive = true;
                    statusTextView.setText("Recording A");
                }
            }
        });
        startBbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aActive){
                    Toast.makeText(MainActivity.this, "Please stop recording A first",
                            Toast.LENGTH_SHORT).show();
                }else{
                    bActive = true;
                    statusTextView.setText("Recording B");
                }
            }
        });
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (aActive || bActive) {
                    Toast.makeText(MainActivity.this, "Stopping Recording",
                            Toast.LENGTH_SHORT);
                    aActive = false;
                    bActive = false;
                    statusTextView.setText("Paused");
                }
            }
        });
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startIntent = new Intent(getApplicationContext(), MapActivity.class);
                startIntent.putExtra("PointA", pointAPoints);
                startIntent.putExtra("PointB", pointBPoints);
                startActivity(startIntent);
            }
        });
    }


}
